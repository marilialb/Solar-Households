from flask import Flask, jsonify, render_template, request, send_from_directory
from simulation import Grid
import threading

app = Flask(__name__, template_folder='template')
grid = Grid(width=15, height=8)
lock = threading.Lock()

@app.route('/')
def intro():
    return render_template('intro.html')

@app.route('/app')
def index():
    return render_template('index.html')

@app.route("/api/state", methods=["GET"])
def api_state():
    with lock:
        return jsonify(grid.as_dict())
    
@app.route("/api/tick", methods=["POST"])
def api_tick():
    # Optionally accept ?steps=N
    steps = int(request.args.get("steps", 1))
    dt = float(request.args.get("dt", 0.2))
    with lock:
        for _ in range(max(1, steps)):
            grid.step(dt=dt)
        return jsonify(grid.as_dict())

@app.route("/api/reset", methods=["POST"])
def api_reset():
    width = request.args.get("width")
    height = request.args.get("height")
    # Accept optional JSON body: {"weights": {"1": 10, "2": 20, ...}}
    body = request.get_json(silent=True) or {}
    raw_weights = body.get("weights")
    weights = None
    if raw_weights:
        weights = {int(k): float(v) for k, v in raw_weights.items()}

    with lock:
        if width and height:
            grid.reset(width=int(width), height=int(height), weights=weights)
        else:
            grid.reset(weights=weights)
        return jsonify({"status": "ok", **grid.as_dict()})


@app.route("/pis.pdf")
def pis_pdf():
    return send_from_directory("/root/flask_app/template", "PIS.pdf", mimetype="application/pdf", as_attachment=False)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
