# simulation.py
import random
import math
import threading


def sigmoid(x):
    x = max(-20, min(20, x))          # clamp to avoid overflow
    return 1 / (1 + math.exp(-x))


def sigmoid_deriv(s):
    """Derivative of sigmoid given its *output* s (not input)."""
    return s * (1 - s)

# ═══════════════════════════════════════════════════════════════════════════════

class TinyMLP:
    """
    Tiny 2-layer MLP (6→4→1) trained online to maximise solar self-consumption.
    Weights are updated after every simulation tick using a lightweight
    policy-gradient-style rule – no external library required.
    """
    N_IN  = 6
    N_HID = 4
    N_OUT = 1

    def __init__(self, lr=0.05, baseline_decay=0.95):
        # Xavier-ish init: scale by 1/sqrt(fan_in)
        scale_ih = 1 / math.sqrt(self.N_IN)
        scale_ho = 1 / math.sqrt(self.N_HID)

        # Hidden layer: N_HID × N_IN weights + N_HID biases
        self.W1 = [[random.uniform(-scale_ih, scale_ih)
                    for _ in range(self.N_IN)]
                   for _ in range(self.N_HID)]
        self.b1 = [0.0] * self.N_HID

        # Output layer: N_OUT × N_HID weights + N_OUT biases
        self.W2 = [[random.uniform(-scale_ho, scale_ho)
                    for _ in range(self.N_HID)]
                   for _ in range(self.N_OUT)]
        self.b2 = [0.0] * self.N_OUT

        self.lr = lr
        self.baseline      = 0.0        # exponential moving average of reward
        self.baseline_decay = baseline_decay

        # Cached activations for use in train()
        self._last_inputs  = None
        self._last_hidden  = None
        self._last_output  = None

        # Diagnostics
        self.reward_history = []
        self.ticks_trained  = 0

    # ── Forward pass ──────────────────────────────────────────────────────────
    def forward(self, inputs: list[float]) -> float:
        """Run the network and cache activations.  Returns a scalar in (0,1)."""
        self._last_inputs = inputs[:]

        # Hidden layer
        hidden = []
        for j in range(self.N_HID):
            z = self.b1[j] + sum(self.W1[j][i] * inputs[i] for i in range(self.N_IN))
            hidden.append(sigmoid(z))
        self._last_hidden = hidden

        # Output layer
        out_z = self.b2[0] + sum(self.W2[0][j] * hidden[j] for j in range(self.N_HID))
        output = sigmoid(out_z)
        self._last_output = output

        return output

    # ── Backward pass (online REINFORCE-lite) ─────────────────────────────────
    def train(self, reward: float):
        """Update weights given the scalar reward for the last forward pass."""
        if self._last_inputs is None:
            return                      # nothing cached yet

        self.ticks_trained += 1
        self.reward_history.append(reward)

        # Update exponential baseline
        self.baseline = (self.baseline_decay * self.baseline
                         + (1 - self.baseline_decay) * reward)
        advantage = reward - self.baseline

        # --- Output layer gradient ---
        # dL/d(out_z) = advantage × σ'(output)
        delta_out = advantage * sigmoid_deriv(self._last_output)

        # Update W2 and b2
        for j in range(self.N_HID):
            self.W2[0][j] += self.lr * delta_out * self._last_hidden[j]
        self.b2[0] += self.lr * delta_out

        # --- Hidden layer gradient ---
        for j in range(self.N_HID):
            # Back-prop through output weight
            delta_hid = delta_out * self.W2[0][j] * sigmoid_deriv(self._last_hidden[j])
            for i in range(self.N_IN):
                self.W1[j][i] += self.lr * delta_hid * self._last_inputs[i]
            self.b1[j] += self.lr * delta_hid

    # ── Diagnostics ───────────────────────────────────────────────────────────
    def avg_reward(self, n=50) -> float:
        """Mean reward over the last n ticks."""
        if not self.reward_history:
            return 0.0
        window = self.reward_history[-n:]
        return sum(window) / len(window)


# ═══════════════════════════════════════════════════════════════════════════════


class Household:
    ENERGY_CENTERED = "energy"
    CONSUMPTION_CENTERED = "consumption"

    ARCHETYPES = {
        1: {"name": "Solar Neglect", "symbol": "N"},
        2: {"name": "Solar Disengaged", "symbol": "D"},
        3: {"name": "Solar Constrained", "symbol": "C"},
        4: {"name": "Solar Pragmatic", "symbol": "P"},
        5: {"name": "Solar Critical", "symbol": "R"},
        6: {"name": "No/Low Solar", "symbol": "L"},
    }

    BASELINE_COST = {
        1: 4.0, #Neglect: moderate drain
        2: 3.0, #Disengaged
        3: 2.5, #Constrained
        4: 0.8, #Pragmatic: nearly self-sufficient, low drain
        5: 2.0, #Critical
        6: 6.0, #No/Low Solar: most dependent, highest drain
    }

    # Minimum pooled budget needed from neighbours to trigger a rebirth
    REBIRTH_THRESHOLD = 50.0
    # Each willing neighbour donates this much budget and energy
    DONATION_BUDGET  = 25.0
    DONATION_ENERGY  = 2.0

    def __init__(self, x, y, state_type):
        self.x = x
        self.y = y
        self.state_type = state_type

        self.name = self.ARCHETYPES[state_type]["name"]
        self.symbol_code = self.ARCHETYPES[state_type]["symbol"]

        self._init_stats()

    def _init_stats(self):
        #Initialise (or re-initialise of rebirth) all household stats.
        state_type = self.state_type

        # ---------- Population ----------
        pop_ranges = {1:(2,4),2:(2,5),3:(3,6),4:(2,4),5:(2,5),6:(3,7)}
        self.population = random.randint(*pop_ranges[state_type])

        # ---------- Income ----------
        income_ranges = {
            1:(1100,1800),2:(500,1100),3:(500,1100),
            4:(1100,1800),5:(500,1100),6:(150,500),
        }
        self.income = random.uniform(*income_ranges[state_type])
        #self.budget = self.income * random.uniform(4, 8)
        budget_ranges = {
            1:(1.5,2.5),2:(1.5,2.5), 3:(1.5,2.5),
            4:(2.0,3.5),5:(1.5,2.5),6:(1.0,1.8),
        }
        self.budget = self.income * random.uniform(*budget_ranges[state_type])

        # ---------- Solar ----------
        solar_ranges = {
            1:(0,2),2:(1,3),3:(0.5,2),4:(7,12),5:(2,5),6:(0,1),
        }
        self.solar_capacity = random.uniform(*solar_ranges[state_type])

        # ---------- Battery ----------
        storage_ranges = {
            1:(10,18),2:(8,14),3:(5,10),4:(18,30),5:(10,16),6:(3,6),
        }
        self.storage_capacity = random.uniform(*storage_ranges[state_type])
        self.stored_energy    = random.uniform(0, self.storage_capacity)

        # ---------- Efficiency ----------
        efficiency_ranges = {
            1:(0.7,0.9),2:(0.8,1.0),3:(0.9,1.1),
            4:(0.6,0.8),5:(0.8,1.0),6:(1.0,1.3),
        }
        self.appliance_efficiency = random.uniform(*efficiency_ranges[state_type])

        # ---------- Behaviour ----------
        self.behaviour = (
            self.ENERGY_CENTERED
            if state_type in [1, 4]
            else self.CONSUMPTION_CENTERED
        )

        # ---------- EV ----------
        self.has_ev = random.random() < {
            1:0.7,2:0.4,3:0.2,4:0.7,5:0.4,6:0.1
        }[state_type]

        if self.has_ev:
            self.ev_capacity = random.uniform(20, 60)
            self.ev_charge   = random.uniform(0.2, 0.8) * self.ev_capacity
        else:
            self.ev_capacity = 0
            self.ev_charge   = 0

         # ---------- TinyML weights ----------
        #self.weights = [random.uniform(-1, 1) for _ in range(3)]
        #self.bias = random.uniform(-1, 1)

        # ──────────────────────────────────────────────────────────────────────
        # TinyMLP replaces the old random-weight heuristic.
        # Each household has its own model that trains online from its own
        # experience – capturing archetype-specific solar usage patterns.
        # ──────────────────────────────────────────────────────────────────────
        self.brain = TinyMLP(lr=0.05)

        # metrics
        self.wastefulness = 0
        self.comfort      = 0
        self.alive        = True

        # cost/benefit accumulators (reset each tick)
        self.cost_deficit   = 0.0
        self.cost_bought    = 0.0
        self.benefit_export = 0.0
        self.benefit_sold   = 0.0

        # track last-tick values so we can compute the reward
        self._last_production      = 0.0
        self._last_overflow        = 0.0
        self._last_deficit         = 0.0
        self._last_solar_used_local = 0.0
        self.ticks_dead = 0.0

    def revive(self, donated_budget, donated_energy):
        #Called by Grid.rebirth() when neighbours pool enough resources.
        self._init_stats()
        # Start with the donated resources instead of normal starting budget
        self.budget        = donated_budget
        self.stored_energy = min(donated_energy, self.storage_capacity)
        self.alive         = True
        self.ticks_dead    = 0

    # ── Helpers ────────────────────────────────────────────────────────────────
    def solar_production(self, t):
        return max(0, math.sin(t)) * self.solar_capacity

    def base_consumption(self):
        return self.population * 1.2 * self.appliance_efficiency

    # ── Feature extraction ────────────────────────────────────────────────────
    def _build_inputs(self, production: float, t: float) -> list[float]:
        """Return the 6-element normalised input vector for the TinyMLP."""
        return [
            self.stored_energy / (self.storage_capacity + 1e-6),   # 0: SOC
            production / (self.solar_capacity + 1e-6),              # 1: solar fraction
            (math.sin(t) + 1) / 2,                                  # 2: time-of-day [0,1]
            min(self.budget / 5000.0, 1.0),                         # 3: budget headroom
            self.ev_charge / (self.ev_capacity + 1e-6),             # 4: EV SOC
            min(self.base_consumption() / 10.0, 1.0),               # 5: demand proxy
        ]

    # ── Reward computation ────────────────────────────────────────────────────
    def _compute_reward(self) -> float:
        """
        Scalar reward ∈ [-1, 1] that rewards solar self-consumption and
        penalises wasted overflow and deficit.

        Components:
          + self_consumption_rate  (solar actually used locally / produced)
          - overflow_rate          (solar wasted to grid due to full battery)
          - deficit_rate           (energy need unmet)
        """
        prod  = self._last_production + 1e-6
        cap   = self.storage_capacity + 1e-6

        self_consumption_rate = min(self._last_solar_used_local / prod, 1.0)
        overflow_rate         = min(self._last_overflow / cap, 1.0)
        deficit_rate          = min(self._last_deficit  / cap, 1.0)

        reward = self_consumption_rate - 0.6 * overflow_rate - 0.8 * deficit_rate
        return max(-1.0, min(1.0, reward))

    # ── EV charging ────────────────────────────────────────────────────────────
    def ev_charging(self, available_energy, decision_factor):
        if not self.has_ev:
            return 0

        desired = self.ev_capacity * 0.8
        if self.ev_charge >= desired:
            return 0

        demand = desired - self.ev_charge

        if self.behaviour == self.ENERGY_CENTERED:
            aggressiveness = 0.6 + 0.4 * decision_factor
        else:
            aggressiveness = 0.8

        requested  = min(demand, random.uniform(1.0, 3.0) * aggressiveness)
        safe_limit = available_energy * 0.7
        actual     = min(requested, safe_limit)

        self.ev_charge += actual
        return actual

    # ---------------- MAIN STEP ----------------

    def step(self, t):
        if not self.alive:
            self.ticks_dead += 1
            return

        # Reset per-tick accumulators
        self.cost_deficit   = 0.0
        self.cost_bought    = 0.0
        self.benefit_export = 0.0
        self.benefit_sold   = 0.0

        production = self.solar_production(t)
        base       = self.base_consumption()

        # ── TinyMLP forward pass ──────────────────────────────────────────────
        inputs   = self._build_inputs(production, t)
        decision = self.brain.forward(inputs)          # ← replaces old heuristic
        # decision ∈ (0,1):  high → use more solar now,  low → conserve

        # ── EV charging ───────────────────────────────────────────────────────
        energy_buffer = self.storage_capacity * 0.15
        available     = max(0, production + self.stored_energy - energy_buffer)
        ev_use        = self.ev_charging(available, decision)

        # ── Main consumption ──────────────────────────────────────────────────
        if self.behaviour == self.ENERGY_CENTERED:
            consumption = base * (0.8 + 0.6 * decision)
        else:
            consumption = base * 1.5

        effective_consumption = consumption / (self.appliance_efficiency + 1e-6)

        # ── Energy balance ────────────────────────────────────────────────────
        # Track how much solar was consumed locally (before battery clipping)
        solar_into_store   = max(0, production - effective_consumption - ev_use)
        solar_used_locally = production - max(0, solar_into_store - (self.storage_capacity - self.stored_energy))
        solar_used_locally = max(0, min(solar_used_locally, production))

        self.stored_energy += production - effective_consumption - ev_use

       # ── V2H discharge ─────────────────────────────────────────────────────
        v2h_discharge = 0.0
        if self.stored_energy < self.storage_capacity * 0.2:
            urgency       = 1 - (self.stored_energy / (self.storage_capacity * 0.2))
            v2h_discharge = min(self.ev_charge, 2.0 * urgency * decision)
            self.ev_charge     -= v2h_discharge
            self.stored_energy += v2h_discharge

        # ── Overflow / deficit ────────────────────────────────────────────────
        overflow = 0.0
        if self.stored_energy > self.storage_capacity:
            overflow            = self.stored_energy - self.storage_capacity
            earned              = overflow * 0.4
            self.budget        += earned
            self.benefit_export = earned
            self.stored_energy  = self.storage_capacity

        deficit = 0.0
        if self.stored_energy < 0:
            deficit             = min(-self.stored_energy, self.storage_capacity * 0.5)
            self.stored_energy  = 0
            penalty_rate = {1:1.2, 2:1.0, 3:0.9, 4:0.7, 5:1.0, 6:1.8}[self.state_type]
            penalty = deficit * penalty_rate
            self.cost_deficit  += penalty
            self.budget        -= penalty

        # ── Baseline grid cost (offset by solar production) ───────────────────
        baseline_cost = self.BASELINE_COST[self.state_type]
        solar_offset  = min(baseline_cost, production * 0.5)
        net_baseline  = baseline_cost - solar_offset
        self.budget       -= net_baseline
        self.cost_deficit += net_baseline

        # ── Comfort & wastefulness ────────────────────────────────────────────
        ideal        = base
        unmet        = max(0, ideal - consumption)
        self.comfort = max(0, min(1, 1 - unmet / (ideal + 1e-6)))
        if self.stored_energy < self.storage_capacity * 0.2:
            self.comfort *= 0.9

        self.wastefulness = sigmoid(overflow / (self.storage_capacity + 1e-6))

        # ── Cache tick outcomes for reward ────────────────────────────────────
        self._last_production       = production
        self._last_overflow         = overflow
        self._last_deficit          = deficit
        self._last_solar_used_local = solar_used_locally

        # ── TinyMLP backward pass (online training) ───────────────────────────
        reward = self._compute_reward()
        self.brain.train(reward)

        # ── Collapse check ────────────────────────────────────────────────────
        if self.budget < 0:
            self.alive = False

    def symbol(self):
        return "X" if not self.alive else self.symbol_code

# ═══════════════════════════════════════════════════════════════════════════════
class Grid:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.time = 0.0
       # self._lock = threading.Lock()
        self._lock = threading.RLock()
        self.create_population()
        self.market_price = 0.3
        self.total_rebirths = 0

    def create_population(self, weights=None):
        """
        weights: dict mapping archetype id (1–6) to a relative weight.
                 e.g. {1: 10, 2: 20, 3: 15, 4: 25, 5: 20, 6: 10}
                 Defaults to equal distribution if None or all-zero.
        """
        if not weights or sum(weights.values()) == 0:
            weights = {i: 1 for i in range(1, 7)}

        archetype_ids = list(weights.keys())
        archetype_weights = [weights[k] for k in archetype_ids]

        self.cells = []
        for y in range(self.height):
            row = []
            for x in range(self.width):
                state_type = random.choices(archetype_ids, weights=archetype_weights, k=1)[0]
                row.append(Household(x, y, state_type))
            self.cells.append(row)
        self.total_rebirths = 0

    def get_neighbors(self, x, y):
        neighbors = []
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        for dx, dy in directions:
            nx = x + dx
            ny = y + dy
            if 0 <= nx < self.width and 0 <= ny < self.height:
                neighbors.append(self.cells[ny][nx])
        return neighbors

    def step(self, dt=0.2):
        with self._lock:
            self.time += dt
            for row in self.cells:
                for cell in row:
                    cell.step(self.time)

            # --- aggregate metrics ---
            total_energy = 0.0
            total_capacity = 0.0

            for row in self.cells:
                for cell in row:
                    if not cell.alive:
                        continue
                    total_energy += cell.stored_energy
                    total_capacity += cell.storage_capacity

            self.total_energy = total_energy
            self.total_capacity = total_capacity

            scarcity = 1 - (total_energy / (total_capacity + 1e-6))
            self.market_price = 0.2 + 0.8 * sigmoid(5 * (scarcity - 0.5))

            self.energy_exchange()
            self.rebirth()

    #Rebirth here (I will need to rewrite by hand due Visual Graphics)
    def rebirth(self):
        """
        For each collapsed cell, willing neighbours pool budget and energy.
        A neighbour is "willing" if their stored_energy > 50% capacity AND
        their budget is above a comfortable threshold (reasonably healthy).
        If the pool meets the rebirth threshold the cell revives.
        """
        for y in range(self.height):
            for x in range(self.width):
                cell = self.cells[y][x]
                if cell.alive:
                    continue
                # Collect willing donors
                donors = [
                    n for n in self.get_neighbors(x, y)
                    if n.alive
                    and n.stored_energy > n.storage_capacity * 0.15
                    and n.budget > n.income * 0.8   # won't donate if close to trouble
                ]

                if not donors:
                    continue

                # Pool donations
                pooled_budget = len(donors) * Household.DONATION_BUDGET
                pooled_energy = len(donors) * Household.DONATION_ENERGY

                if pooled_budget < Household.REBIRTH_THRESHOLD:
                    continue    # not enough neighbours — stays dead

                # Deduct from donors
                per_donor_budget = pooled_budget / len(donors)
                per_donor_energy = pooled_energy / len(donors)
                for n in donors:
                    n.budget        -= per_donor_budget
                    n.stored_energy -= per_donor_energy

                cell.revive(pooled_budget, pooled_energy)
                self.total_rebirths += 1


    def energy_exchange(self):
        for y in range(self.height):
            for x in range(self.width):
                cell = self.cells[y][x]
                if not cell.alive:
                    continue
                neighbors = self.get_neighbors(x, y)
                for neighbor in neighbors:
                    if not neighbor.alive:
                        continue
                    if (cell.stored_energy < cell.storage_capacity * 0.3 and
                    neighbor.stored_energy > neighbor.storage_capacity *0.5):

                        sender_surplus = neighbor.stored_energy - neighbor.storage_capacity * 0.5
                        sender_offer = sender_surplus *0.10
                        receiver_gap = cell.storage_capacity * 0.3 - cell.stored_energy
                        transfer = max(0, min(sender_offer, receiver_gap, neighbor.stored_energy))

                        max_affordable = cell.budget * 0.05
                        max_transferable = max_affordable / (self.market_price + 1e-6)
                        transfer = max(0, min(transfer, max_transferable))

                        if transfer <= 0:
                            continue

                        payment = transfer * self.market_price
                        neighbor.stored_energy -= transfer
                        cell.stored_energy += transfer
                        cell.budget -= payment
                        cell.cost_bought += payment
                        neighbor.budget += payment
                        neighbor.benefit_sold += payment


    def archetype_stats(self):
        alive = [
            c for row in self.cells
            for c in row
            if c.alive
        ]

        result = {}

        for archetype_id, info in Household.ARCHETYPES.items():
            group = [c for c in alive if c.state_type == archetype_id]

            if not group:
                result[info["symbol"]] = {
                    "name": info["name"],
                    "n": 0
                }
                continue

            n = len(group)
            comfort  = sum(c.comfort        for c in group) / n
            waste    = sum(c.wastefulness   for c in group) / n
            deficit  = sum(c.cost_deficit   for c in group) / n
            bought   = sum(c.cost_bought    for c in group) / n
            export_b = sum(c.benefit_export for c in group) / n
            sold     = sum(c.benefit_sold   for c in group) / n
            net      = export_b + sold - deficit - bought
            ml_rew   = sum(c.brain.avg_reward() for c in group) / n

            result[info["symbol"]] = {
                "name": info["name"],
                "n": n,
                "comfort": comfort,
                "waste": waste,
                "cost_deficit": deficit,
                "cost_bought": bought,
                "benefit_export": export_b,
                "benefit_sold": sold,
                "net": net,
                "ML-Reward": ml_rew,
            }

        # grid averages
        n_alive = len(alive)

        if n_alive:
            grid_net = sum(
                c.benefit_export + c.benefit_sold
                - c.cost_deficit - c.cost_bought
                for c in alive
            ) / n_alive

            avg_rew = sum(
                c.brain.avg_reward() for c in alive
            ) / n_alive
        else:
            grid_net = 0.0
            avg_rew = 0.0

        grid_avg = {
            "alive": n_alive,
            "comfort": sum(c.comfort for c in alive) / n_alive if n_alive else 0,
            "waste": sum(c.wastefulness for c in alive) / n_alive if n_alive else 0,
            "cost_deficit": sum(c.cost_deficit for c in alive) / n_alive if n_alive else 0,
            "cost_bought": sum(c.cost_bought for c in alive) / n_alive if n_alive else 0,
            "benefit_export": sum(c.benefit_export for c in alive) / n_alive if n_alive else 0,
            "benefit_sold": sum(c.benefit_sold for c in alive) / n_alive if n_alive else 0,
            "net": grid_net,
            "ML-Reward": avg_rew,

        }

        return result, grid_avg


    def stats(self):
        counts = {v["symbol"]: 0 for v in Household.ARCHETYPES.values()}
        collapsed = 0
        for row in self.cells:
            for cell in row:
                if not cell.alive:
                    collapsed += 1
                else:
                    counts[cell.symbol_code] += 1
        return counts, collapsed

    def as_dict(self):
        counts, collapsed = self.stats()
        archetype_stats, grid_avg = self.archetype_stats()
        return {
            "time": round(self.time, 2),
            "width": self.width,
            "height": self.height,
            #Allow mouse over data
            "grid": [
                        [
                            {
                                "symbol": cell.symbol(),
                                "comfort": cell.comfort,
                                "waste": cell.wastefulness,
                                "cost_deficit": cell.cost_deficit,
                                "cost_bought": cell.cost_bought,
                                "benefit_export": cell.benefit_export,
                                "benefit_sold": cell.benefit_sold,
                                "net": (
                                    cell.benefit_export + cell.benefit_sold
                                    - cell.cost_deficit - cell.cost_bought
                                ),
                                "ML-Reward": cell.brain.avg_reward(),
                                "population": cell.population,
                            }
                            for cell in row
                        ]
                        for row in self.cells
                    ],
            "counts": counts,
            "collapsed": collapsed,
            "archetypes": Household.ARCHETYPES,
            "archetype_stats": archetype_stats,
            "grid_avg": grid_avg,

        }

    def reset(self, width=None, height=None, weights=None):
        with self._lock:
            if width is not None and height is not None:
                self.width = int(width)
                self.height = int(height)
            self.time = 0.0
            self.create_population(weights=weights)
